#include <stdio.h>

int x;
float y=4;
float z = 122.53;
char x = 'c';
char r;
r = 'z';

int f = x ^ 2;
x = x / 3;

if ((x) >= (y) ) {
     z=45+3*x;
    for(int i=0; i<12; i=i+1;){
    c=x;
    } 
}
else {
    c = 32;
}


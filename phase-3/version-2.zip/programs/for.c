#include<stdio.h>
#include<math.h>

int c=0;
for(int i=0; i<5;i=i+1;){
    c = 2+i;
}
int a=1;
int c=1;

while(c==1){
    if(a == 2){
        c = c+1;
    }else{
        a=2;
    }
}

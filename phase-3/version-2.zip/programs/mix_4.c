#include <stdio.h>

int x;
int y;
int z;

float f = x + ( z + y ) ^ 4 / 3;

do{
    z=z+x*f;
    for(int i=0; i<12; i=i+1;){
    c=x;
    for(int k=1; k<24; k=k+1;){
        z=c+k;
    }
    }
}
while(z>0)




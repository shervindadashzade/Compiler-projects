#include <stdio.h>

 int x;

 int y=2;
 float z = 2.3;

 char x = 'c';

 char r;
 r = 'z';

 int f = x + ( z + y ) ^ 2;


 x = x + 2;


 if ((x) > (y) ) {
      z=2+3+y; 
 }
 else {
     c = 2;
 }

 while(true){
     x=x+2;
 }

 do{
    z=z+x*u;
 }while(true)


 for(int i=0; i<5; i=i+1;){
     c=x;
        for(int i=0; i<5; i=i+1;){
            c=x;
        }
    int v = 1;
    }

int x = 1;
int y=2;
int c;

x = (y+(x+c)*2)/4 ^ 5;
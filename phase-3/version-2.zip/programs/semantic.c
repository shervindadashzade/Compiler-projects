int i=0;

float i=1;

int i;

c = 1;

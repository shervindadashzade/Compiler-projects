#include<stdio.h>

int a=0;

char r = 'c';

if ( r == a){
    r= 'O';
}